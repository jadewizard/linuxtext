<?php
//ver 2.0

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

require_once 'system/handler.php';
require_once 'system/registration.php';
require_once 'system/logout.php';
require_once 'system/login.php';
require_once 'system/pages.php';
?>
